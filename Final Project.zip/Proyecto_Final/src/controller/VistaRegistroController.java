/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;


import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;
import java.io.IOException;
import model.DatosGlobales;

    
public class VistaRegistroController implements Initializable {

   
    @FXML private TextField txtUsuarioReg;
    @FXML private PasswordField txtPasswordReg;

    @Override
    public void initialize(URL url, ResourceBundle rb) { }    

    @FXML
    private void registrarUsuario(ActionEvent event) {
       
        String nuevoUsuario = txtUsuarioReg.getText();
        String nuevaPassword = txtPasswordReg.getText();
        
       
        if (nuevoUsuario.isEmpty() || nuevaPassword.isEmpty()) {
            Alert alertaError = new Alert(Alert.AlertType.ERROR);
            alertaError.setTitle("Error");
            alertaError.setHeaderText(null);
            alertaError.setContentText("Por favor, llena todos los campos.");
            alertaError.showAndWait();
            return; 
        }
        
        
        DatosGlobales.usuariosGuardados.put(nuevoUsuario, nuevaPassword);
        
 
        Alert alertaExito = new Alert(Alert.AlertType.INFORMATION);
        alertaExito.setTitle("Registro Exitoso");
        alertaExito.setHeaderText(null);
        alertaExito.setContentText("¡Cuenta creada! Ahora puedes iniciar sesión.");
        alertaExito.showAndWait();
        
    
        volverAlLogin(event);
    }

    @FXML
    private void volverAlLogin(ActionEvent event) {
        try {
         
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/vistas/Vistalogin.fxml"));
            Parent root = loader.load();
            
            
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
           
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error al cargar la vista de Login");
        }
    }

}
