package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class VistaAdminController implements Initializable {


    @FXML private TextField txtUsuarioAdmin;
    @FXML private PasswordField txtPasswordAdmin;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    
    }

    @FXML
    private void iniciarSesionAdmin(ActionEvent event) {
        String user = txtUsuarioAdmin.getText();
        String pass = txtPasswordAdmin.getText();

   
        if ("admin".equals(user) && "admin123".equals(pass)) {
            try {
 
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/vistas/VistaAdminGestion.fxml"));
                Parent root = loader.load();
                
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                Scene scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
                
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("Error: Falta crear el archivo VistaAdminGestion.fxml");
            }
        } else {
    
            Alert alerta = new Alert(Alert.AlertType.ERROR);
            alerta.setTitle("Acceso denegado");
            alerta.setHeaderText(null);
            alerta.setContentText("Usuario o contraseña de administrador incorrectos.");
            alerta.showAndWait();
        }
    }

    @FXML
    private void volverAlLogin(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/vistas/Vistalogin.fxml"));
            Parent root = loader.load();
            
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error al cargar la vista de Login");
        }
    }
}