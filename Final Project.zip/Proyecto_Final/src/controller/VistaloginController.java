package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.DatosGlobales;

public class VistaloginController implements Initializable {


    @FXML private TextField txtUsuarioLogin;
    @FXML private PasswordField tctPasswordLogin; 

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }    


    @FXML
    private void IngresarApp(ActionEvent event) {
        DatosGlobales.esAdmin = false; 
        String usuarioIngresado = txtUsuarioLogin.getText();
        String passwordIngresada = tctPasswordLogin.getText();

        if (usuarioIngresado.isEmpty() || passwordIngresada.isEmpty()) {
            mostrarAlerta("Campos vacíos", "Por favor, completa los datos.", Alert.AlertType.WARNING);
            return;
        }


        if (DatosGlobales.usuariosGuardados.containsKey(usuarioIngresado) && 
            DatosGlobales.usuariosGuardados.get(usuarioIngresado).equals(passwordIngresada)) {
            
            System.out.println("Acceso correcto. Cargando Catálogo...");
            cargarEscena("/vistas/VistaCatalogo.fxml", event);
        } else {
            mostrarAlerta("Error", "Usuario o contraseña incorrectos.", Alert.AlertType.ERROR);
        }
        
    }

    @FXML
    private void abrirAdmin(ActionEvent event) {
        cargarEscena("/vistas/VistaAdmin.fxml", event);
    }

    @FXML
    private void abrirRegistro(ActionEvent event) {
        cargarEscena("/vistas/VistaRegistro.fxml", event);
    }

    private void cargarEscena(String ruta, ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(ruta));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void mostrarAlerta(String titulo, String msg, Alert.AlertType tipo) {
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(msg);
        alerta.showAndWait();
    }
    @FXML
private void abrirRecuperar(ActionEvent event) {
    try {
     
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/vistas/VistaRecuperar.fxml"));
        Parent root = loader.load();
        

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    } catch (IOException e) {
        e.printStackTrace();
        System.out.println("Error: No se pudo abrir la pantalla de recuperación.");
    }
}
 
}