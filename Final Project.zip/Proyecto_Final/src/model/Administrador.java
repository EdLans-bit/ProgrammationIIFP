/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;


public class Administrador extends Usuario {

   
    public Administrador(String usuario, String clave) {
    
        super(usuario, clave, "admin");
    }
}