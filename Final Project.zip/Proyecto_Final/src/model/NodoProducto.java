package model;

public class NodoProducto {
    
    public Producto dato;
    public NodoProducto siguiente;

    public NodoProducto(Producto dato) {
        this.dato = dato;
        this.siguiente = null;
    }

    
    public Producto getProducto() {
        return dato;
    }
    
   
    public NodoProducto getSiguiente() {
        return siguiente;
    }
}