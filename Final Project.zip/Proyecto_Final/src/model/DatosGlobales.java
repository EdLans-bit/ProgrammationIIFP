package model;

import java.util.HashMap;

public class DatosGlobales {


    public static HashMap<String, String> usuariosGuardados = new HashMap<>();
    
    static {
      
        usuariosGuardados.put("emiliano", "1234");
        usuariosGuardados.put("edlans", "0000");
    }


    public static model.ListaProductos listaEnlazada = new model.ListaProductos();
    public static model.PilaFavoritos favoritos = new model.PilaFavoritos();
    public static model.ColaCompras carritoCompras = new model.ColaCompras();
    public static model.ColaCompras historialCompras = new model.ColaCompras();
    

    public static boolean esAdmin = false; 

    static {
        cargarProductosIniciales();
    }

    private static void cargarProductosIniciales() {
        listaEnlazada.agregar(new Producto(
                "iPhone 15 Pro",
                4299000,
                8,
                "Pantalla Super Retina XDR, chip A17 Pro, camara principal de 48 MP y acabado en titanio.",
                imagen("/imagenes/iphone15.jpg")
        ));

        listaEnlazada.agregar(new Producto(
                "iPad Pro 11",
                3899000,
                6,
                "Tablet de 11 pulgadas con alto rendimiento, ideal para estudio, diseno y entretenimiento.",
                imagen("/imagenes/ipadpro.jpg")
        ));

        listaEnlazada.agregar(new Producto(
                "Apple Watch Series 9",
                1699000,
                12,
                "Reloj inteligente con monitoreo de actividad, salud, notificaciones y pantalla brillante.",
                imagen("/imagenes/applewatch.png")
        ));

        listaEnlazada.agregar(new Producto(
                "iMac 24 M3",
                6499000,
                4,
                "Computador todo en uno con chip M3, pantalla Retina 4.5K y diseno delgado.",
                imagen("/imagenes/imac24.jpg")
        ));

        listaEnlazada.agregar(new Producto(
                "MacBook Air",
                5299000,
                5,
                "Portatil liviano con excelente autonomia, pantalla de alta calidad y rendimiento para trabajo diario.",
                imagen("/imagenes/macbook.png")
        ));

        listaEnlazada.agregar(new Producto(
                "Audifonos JBL Bluetooth",
                299000,
                15,
                "Audifonos inalambricos con estuche de carga, sonido claro y conexion Bluetooth.",
                imagen("/imagenes/jblaudifonos.jpg")
        ));
    }

    private static String imagen(String ruta) {
        return DatosGlobales.class.getResource(ruta).toExternalForm();
    }
}
