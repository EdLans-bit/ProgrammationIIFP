/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import model.Producto;
/**
 *
 * @author UNICORDOBA
 */
public class ListaProductos {
    
    private NodoProducto inicio;
    
    public ListaProductos(){
        inicio = null;
    }
 
    public void agregar(Producto producto){
        
        NodoProducto nuevoNodo = new NodoProducto(producto);
        
        if (inicio == null){
            inicio = nuevoNodo;
        } else {
            NodoProducto aux = inicio;
            
            while (aux.siguiente != null){
                aux = aux.siguiente;
            }
            aux.siguiente = nuevoNodo;
        }
    }
    
    public NodoProducto getInicio() {
        return inicio;
    }
    public void setInicio(NodoProducto inicio) {
        this.inicio = inicio;
    }

public void eliminar(String nombreProducto) {
    if (inicio == null) return;

   
    if (inicio.dato.getNombre().equals(nombreProducto)) {
        inicio = inicio.siguiente;
        return;
    }

    
    NodoProducto aux = inicio;
    while (aux.siguiente != null) {
        if (aux.siguiente.dato.getNombre().equals(nombreProducto)) {
           
            aux.siguiente = aux.siguiente.siguiente;
            return;
        }
        aux = aux.siguiente;
    }
}
}
